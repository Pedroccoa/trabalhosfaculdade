<h1>Listar Atendente</h1>
<?php
//read
$sql = "SELECT * FROM paciente";
$res = $conn->query($sql);
$qtd = $res->num_rows;

//se a variavel qtd for maior que zero
if ($qtd > 0) {
    print "<p>Encontrou <b>$qtd</b> resultado(s)</p>";
    print "<table class='table table-bordered table-striped table-hover'>";
    print "<tr>";
    print "<th>#</th>";
    print "<th>Nome do Paciente</th>";
    print "<th>Endereço</th>";
    print "<th>Telefone</th>";
    print "<th>E-mail</th>";
    print "<th>Ações</th>";
    print "</tr>";
    while ($row = $res->fetch_object()) {
        print "<tr>";
        print "<td>" . $row->nome_paciente . "</td>";
        print "<td>" . $row->endereco_paciente . "</td>";
        print "<td>" . $row->telefone_paciente . "</td>";
        print "<td>" . $row->email_paciente . "</td>";
        print "<td>
					<button onclick=\"location.href='?page=paciente-editar&id_paciente=" . $row->id_paciente . "';\" class='btn btn-success'>Editar</button>

					<button onclick=\"if(confirm('Tem certeza que deseja excluir?')){location.href='?page=paciente-salvar&acao=excluir&id_paciente=" . $row->id_paciente . "';}else{false;}\" class='btn btn-danger'>Excluir</button>
			</td>";
        print "</tr>";
    }
    print "</table>";
}
?>