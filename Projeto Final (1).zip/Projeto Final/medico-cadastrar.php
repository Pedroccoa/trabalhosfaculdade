<h1>Cadastrar Médicos</h1>
<form action="?page=medico-salvar" method="POST">
    <input type="hidden" name="acao" value="cadastrar">
    <div class="mb-3">
        <label>Nome</label>
        <input type="text" name="nome" class="form-control">
    </div>
    <div class="mb-3">
        <label>CRM</label>
        <input type="text" name="CRM" class="form-control" pattern="\d{6}" required placeholder="Digite o CRM: xxxxxx">
    </div>
    <div class="mb-3">
        <label>Telefone</label>
        <input type="tel" name="telefone" class="form-control" required placeholder="(xx) xxxxx-xxxx">
    </div>
    <div class="mb-3">
        <label>Email</label>
        <input type="email" name="email" class="form-control">
    </div>
    <div class="mb-3">
        <button type="submit" class="btn btn-success">Enviar</button>
    </div>
</form>