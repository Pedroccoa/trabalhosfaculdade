<h1>Listar Médicos</h1>
<?php
//read
$sql = "SELECT * FROM medico";
$res = $conn->query($sql);
$qtd = $res->num_rows;

//se a variavel qtd for maior que zero
if ($qtd > 0) {
    print "<p>Encontrou <b>$qtd</b> resultado(s)</p>";
    print "<table class='table table-bordered table-striped table-hover'>";
    print "<tr>";
    print "<th>#</th>";
    print "<th>Nome do Médico</th>";
    print "<th>CRM</th>";
    print "<th>Telefone</th>";
    print "<th>E-mail</th>";
    print "<th>Ações</th>";
    print "</tr>";
    while ($row = $res->fetch_object()) {
        print "<tr>";
        print "<td>" . $row->nome . "</td>";
        print "<td>" . $row->CRM . "</td>";
        print "<td>" . $row->telefone . "</td>";
        print "<td>" . $row->email . "</td>";
        print "<td>
					<button onclick=\"location.href='?page=medico-editar&id_medico=" . $row->id_medico . "';\" class='btn btn-success'>Editar</button>

					<button onclick=\"if(confirm('Tem certeza que deseja excluir?')){location.href='?page=medico-salvar&acao=excluir&id_medico=" . $row->id_medico . "';}else{false;}\" class='btn btn-danger'>Excluir</button>
			</td>";
        print "</tr>";
    }
    print "</table>";
}
?>