<h1>Editar Médicos</h1>
<?php
$sql = "SELECT * FROM medico WHERE id_medico=" . $_REQUEST['id_medico'];
$res = $conn->query($sql);
$row = $res->fetch_object();
?>
<form action="?page=medico-salvar" method="POST">
    <input type="hidden" name="acao" value="editar">
    <input type="hidden" name="id_medico" value="<?php print $row->id_medico; ?>">
    <div class="mb-3">
        <label>Nome</label>
        <input type="text" value="<?php print $row->nome; ?>" name="nome" class="form-control">
    </div>
    <div class="mb-3">
        <label>CRM</label>
        <input type="text" value="<?php print $row->CRM; ?>" name="CRM" class="form-control" pattern="\d{6}" required placeholder="Digite o CRM: xxxxxx">
    </div>
    </div>
    <div class="mb-3">
        <label>Telefone</label>
        <input type="tel" value="<?php print $row->telefone; ?>" name="telefone" class="form-control" required placeholder="(xx) xxxxx-xxxx">
    </div>
    <div class="mb-3">
        <label>Email</label>
        <input type="email" value="<?php print $row->email; ?>" name="email" class="form-control">
        <div class="mb-3">
            <button type="submit" class="btn btn-success">Enviar</button>
        </div>
</form>