<h1>Cadastrar Atendente</h1>
<form action="?page=paciente-salvar" method="POST">
    <input type="hidden" name="acao" value="cadastrar">
    <div class="mb-3">
        <label>Nome</label>
        <input type="text" name="nome_paciente" class="form-control">
    </div>
    <div class="mb-3">
        <label>Endereço</label>
        <input type="text" name="endereco_paciente" class="form-control">
    </div>
    <div class="mb-3">
        <label>Telefone</label>
        <input type="tel" name="telefone_paciente" class="form-control" required placeholder="(xx) xxxxx-xxxx">
    </div>
    <div class="mb-3">
        <label>Email</label>
        <input type="email" name="email_paciente" class="form-control">
    </div>
    <div class="mb-3">
        <button type="submit" class="btn btn-success">Enviar</button>
    </div>
</form>