
<?php
switch ($_REQUEST['acao']) {
    case 'cadastrar':
        $nome = $_POST["nome"];
        $CRM = $_POST["CRM"];
        $telefone = $_POST["telefone"];
        $email = $_POST["email"];

        $sql = "INSERT INTO medico (nome, CRM, telefone, email) VALUES('{$nome}','{$CRM}','{$telefone}','{$email}')";
        $res = $conn->query($sql);
        if ($res == true) {
            print "<script>alert('Cadastrou com sucesso!');</script>";
            print "<script>location.href='?page=medico-listar';</script>";
        } else {
            print "<script>alert('Não foi possível cadastrar');</script>";
            print "<script>location.href='?page=medico-listar';</script>";
        }
        break;

    case 'editar':
        $sql = "UPDATE medico SET
					nome='" . $_POST['nome'] . "',
                    CRM='" . $_POST['CRM'] . "',
                    telefone='" . $_POST['telefone'] . "',
                    email='" . $_POST['email'] . "'
				WHERE
					id_medico=" . $_POST['id_medico'];

        $res = $conn->query($sql);

        if ($res == true) {
            print "<script>alert('Editou com sucesso!');</script>";
            print "<script>location.href='?page=medico-listar';</script>";
        } else {
            print "<script>alert('Não foi possível cadastrar');</script>";
            print "<script>location.href='?page=medico-listar';</script>";
        }
        break;

    case 'excluir':
        $sql = "DELETE FROM medico WHERE id_medico=" . $_REQUEST['id_medico'];

        $res = $conn->query($sql);

        if ($res == true) {
            print "<script>alert('Excluiu com sucesso!');</script>";
            print "<script>location.href='?page=medico-listar';</script>";
        } else {
            print "<script>alert('Não foi possível excluir');</script>";
            print "<script>location.href='?page=medico-listar';</script>";
        }
        break;
}
