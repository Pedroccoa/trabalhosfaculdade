<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Clínica Saúde em Foco</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>

<body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Saúde em Foco</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            Paciente
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="?page=paciente-listar">Listar</a></li>
                            <li><a class="dropdown-item" href="?page=paciente-cadastrar">Cadastrar</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            Médicos
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="?page=medico-listar">Listar</a></li>
                            <li><a class="dropdown-item" href="?page=medico-cadastrar">Cadastrar</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col">
                <?php
                //conexao com o banco
                include('config.php');

                //includes das páginas
                switch (@$_REQUEST['page']) {
                    //paciente
                    case 'paciente-listar':
                        include('paciente-listar.php');
                        break;
                    case 'paciente-cadastrar':
                        include('paciente-cadastrar.php');
                        break;
                    case 'paciente-editar':
                        include('paciente-editar.php');
                        break;
                    case 'paciente-salvar':
                        include('paciente-salvar.php');
                        break;
                    //medico
                    case 'medico-listar':
                        include('medico-listar.php');
                        break;
                    case 'medico-cadastrar':
                        include('medico-cadastrar.php');
                        break;
                    case 'medico-editar':
                        include('medico-editar.php');
                        break;
                    case 'medico-salvar':
                        include('medico-salvar.php');
                        break;

                    default:
                        echo "<h1>Bem vindo a Clinica Saúde em Foco</h1>";
                }
                ?>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="js/bootstrap.bundle.min.js"></script>
</body>

</html>