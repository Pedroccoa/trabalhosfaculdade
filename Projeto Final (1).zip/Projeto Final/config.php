<?php
	define('HOST', 'localhost');
	define('USER', 'root');
	define('PASS', '');
	define('BASE', 'saudefoco');

	$conn = new MySQLi(HOST, USER, PASS, BASE);