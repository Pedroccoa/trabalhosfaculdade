
<?php
switch ($_REQUEST['acao']) {
    case 'cadastrar':
        $nome_paciente = $_POST["nome_paciente"];
        $endereco_paciente     = $_POST["endereco_paciente"];
        $telefone_paciente = $_POST["telefone_paciente"];
        $email_paciente = $_POST["email_paciente"];

        $sql = "INSERT INTO paciente (nome_paciente, endereco_paciente, telefone_paciente, email_paciente) VALUES('{$nome_paciente}','{$endereco_paciente}','{$telefone_paciente}','{$email_paciente}')";
        $res = $conn->query($sql);
        if ($res == true) {
            print "<script>alert('Cadastrou com sucesso!');</script>";
            print "<script>location.href='?page=paciente-listar';</script>";
        } else {
            print "<script>alert('Não foi possível cadastrar');</script>";
            print "<script>location.href='?page=paciente-listar';</script>";
        }
        break;

    case 'editar':
        $sql = "UPDATE paciente SET
					nome_paciente='" . $_POST['nome_paciente'] . "',
                    endereco_paciente='" . $_POST['endereco_paciente'] . "',
                    telefone_paciente='" . $_POST['telefone_paciente'] . "',
                    email_paciente='" . $_POST['email_paciente'] . "'
				WHERE
					id_paciente=" . $_POST['id_paciente'];

        $res = $conn->query($sql);

        if ($res == true) {
            print "<script>alert('Editou com sucesso!');</script>";
            print "<script>location.href='?page=paciente-listar';</script>";
        } else {
            print "<script>alert('Não foi possível cadastrar');</script>";
            print "<script>location.href='?page=paciente-listar';</script>";
        }
        break;

    case 'excluir':
        $sql = "DELETE FROM paciente WHERE id_paciente=" . $_REQUEST['id_paciente'];

        $res = $conn->query($sql);

        if ($res == true) {
            print "<script>alert('Excluiu com sucesso!');</script>";
            print "<script>location.href='?page=paciente-listar';</script>";
        } else {
            print "<script>alert('Não foi possível excluir');</script>";
            print "<script>location.href='?page=paciente-listar';</script>";
        }
        break;
}
